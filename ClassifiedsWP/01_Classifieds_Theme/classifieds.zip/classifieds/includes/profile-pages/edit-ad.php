<?php
require_once( classifieds_load_path( 'includes/profile-pages/ad-form.php' ) );
?>