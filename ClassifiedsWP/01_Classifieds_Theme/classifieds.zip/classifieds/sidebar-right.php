<div class="col-md-4">
<?php 
	if ( is_active_sidebar( 'sidebar-right' ) ){
		dynamic_sidebar( 'sidebar-right' );
	}
?>
</div>