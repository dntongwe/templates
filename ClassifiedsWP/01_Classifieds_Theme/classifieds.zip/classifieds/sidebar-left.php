<div class="col-md-4">
<?php 
	if ( is_active_sidebar( 'sidebar-left' ) ){
		dynamic_sidebar( 'sidebar-left' );
	}
?>
</div>