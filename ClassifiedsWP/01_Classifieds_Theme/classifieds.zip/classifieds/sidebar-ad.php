<?php 
	if ( is_active_sidebar( 'sidebar-ad' ) ){
		dynamic_sidebar( 'sidebar-ad' );
	}
?>