<?php
/*
    Template Name: Home Page
*/
get_header();
the_post();

the_content();

get_footer();