<?php 
	if ( is_active_sidebar( 'sidebar-product' ) ){
		dynamic_sidebar( 'sidebar-product' );
	}
?>