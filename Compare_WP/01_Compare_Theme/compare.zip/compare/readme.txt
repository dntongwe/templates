Compare - Coupon Theme - by pebas
http://themeforest.net/user/pebas