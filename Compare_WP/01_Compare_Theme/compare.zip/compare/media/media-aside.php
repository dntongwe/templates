<div class="embed-responsive embed-responsive-16by9">
	<?php the_post_thumbnail( $image_size, array( 'class' => 'embed-responsive-item' ) ) ?>
</div>