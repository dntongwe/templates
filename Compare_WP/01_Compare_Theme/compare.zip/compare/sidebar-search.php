<?php 
	if ( is_active_sidebar( 'sidebar-search' ) ){
		dynamic_sidebar( 'sidebar-search' );
	}
?>